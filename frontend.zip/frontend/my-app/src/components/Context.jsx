import React,{useState} from "react"


function Context({sales})
{
    



}
export default Context